package com.sistempakar

class CertaintyFactor {
    val cfg1: Double = 0.5
    val cfg2: Double = 0.3
    val cfg3: Double = 0.3
    val cfg4: Double = 0.2
    val cfg5: Double = 0.5
    val cfg6: Double = 0.3
    val cfg7: Double = 0.5
    val cfg8: Double = 0.5
    val cfg9: Double = 0.5
    val cfg10: Double = 0.6
    val cfg11: Double = 0.5
    val cfg12: Double = 0.7

    fun CFtotal1(): Double {
        return cfg1 + cfg2 * (1 - cfg1)
    }

    fun CFtotal2(): Double {
        return CFtotal1() + cfg3 * (1 - CFtotal1())
    }

    fun CFtotal3(): Double {
        return CFtotal2() + cfg4 * (1 - CFtotal2())
    }

    fun CFtotal4(): Double {
        return CFtotal3() + cfg5 * (1 - CFtotal3())
    }

    fun CFtotal5(): Double {
        return CFtotal4() + cfg6 * (1 - CFtotal4())
    }

    fun CFtotal6(): Double {
        return CFtotal5() + cfg7 * (1 - CFtotal5())
    }

    fun CFtotal7(): Double {
        return CFtotal6() + cfg8 * (1 - CFtotal6())
    }

    fun CFtotal8(): Double {
        return CFtotal7() + cfg9 * (1 - CFtotal7())
    }

    fun CFtotal9(): Double {
        return CFtotal8() + cfg10 * (1 - CFtotal8())
    }

    fun CFtotal10(): Double {
        return CFtotal9() + cfg11 * (1 - CFtotal9())
    }

    fun CFtotal11(): Double {
        return CFtotal10() + cfg12 * (1 - CFtotal10())
    }
}

